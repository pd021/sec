#include <stdio.h>
#include <cstdint>
#include <cmath>
#include <fstream>
#include <pulse/simple.h>
#include <pulse/error.h>
#include <iostream>
#include <vector>
using namespace std;
// TRNG settings
const double   Coupling = 0.005;
const double   Control  = 1.99999;
const uint64_t Iterations = 4; // should be 4 according to the papar

union DoubleUInt64 { double d; uint64_t u; };

// for debug
void printBinary(uint64_t value) {
    for (int i = 63; i >= 0; --i) {
        std::cout << ((value >> i) & 1);
    }
    std::cout << std::endl;
}

double f_T (double x) {
    if (x >= 0.0 && x <  0.5) { return Coupling * x; }
    else { return Coupling * (1.0 - x); }
}

int main() {
    // TRNG variables
    double X[8];
    X[0] = 0.141592;
    X[1] = 0.653589;
    X[2] = 0.793238;
    X[3] = 0.462643;
    X[4] = 0.383279;
    X[5] = 0.502884;
    X[6] = 0.197169;
    X[7] = 0.399375;
    double X_new[8];
    uint64_t N = 6000000; // Required numbers
    vector <uint8_t> Output;

    // Create the PulseAudio simple API client
    pa_simple *AudioStream;
    pa_sample_spec StreamSpecs;
    StreamSpecs.format = PA_SAMPLE_U8; // unsigned 8 bit / samp 
    StreamSpecs.channels = 2;
    StreamSpecs.rate = 44100;
    int ErrorCode;

    // Audio stream setup and error handling
    AudioStream = pa_simple_new(NULL, "Capture", PA_STREAM_RECORD, NULL, "record", &StreamSpecs, NULL, NULL, &ErrorCode);
    if (!AudioStream) { cerr << "pa_simple_new() failed: " << pa_strerror(ErrorCode) << endl; return 1; }
    
    uint64_t RequiredSamples = (uint64_t) (((N + 31) / 32) * 8) + 10000;
    uint8_t  Samples[RequiredSamples];
    uint64_t SamplesIndex = 9999 + 1;

    // record samples
    if (pa_simple_read(AudioStream, Samples, sizeof(Samples), &ErrorCode) < 0) { 
        cerr << "pa_simple_read() failed: " << pa_strerror(ErrorCode) << endl;
        pa_simple_free(AudioStream); return 1;
    }
    pa_simple_free(AudioStream);

    // TRNG
    while (Output.size() < N) {
        // Entropy input
        for(int i = 0; i < 8; i++) {
            uint8_t R = (uint8_t) (Samples[SamplesIndex++] & 0b00000111);
            X[i] = ((0.71428571 * R) + X[i]) * 0.666666667;
        }

        // Multi-iteration
        for(int iter = 0; iter < Iterations; iter++) {
            for(int i = 0; i < 8; i++) {
                X_new[i] =
                (1 - Coupling) * f_T(X[i])         +
                (Coupling / 2) * f_T(X[(i+1) % 8]) +
                f_T(X[(i-1) % 8]);
            }
            // X_0 -> X_1 etc. 
            for(int c = 0; c < 8; c++){ X[c] = X_new[c]; }
        }

        // Convert double to uint64, the double is always ~0 so copy bits directly
        DoubleUInt64 Adapter;
        uint64_t U[8];
        for(int i = 0; i < 8; i++){
            Adapter.d = X[i];
            U[i] = Adapter.u;
        }

        // Connect two numbers into 1
        uint64_t Z[4]; uint8_t ZPointer = 0;
        for(int i = 0; i < 8; i += 2){
            Z[ZPointer++] = (U[i] ^ __builtin_bswap64(U[i+1]));
        }
        ZPointer = 0;
        
        // Split 4 x 64 bits into 32 x 8 bit
        uint64_t Mask8 = 0x000000000000ff;
        for(int o = 0; o < 4; o++){
            for(int i = 0; i < 8; i++){
                uint8_t Temp = (uint8_t) ((Z[o] & Mask8) >> 8*i);
                Mask8 <<= 8;
                Output.push_back(Temp);
            }
            Mask8 = 0x000000000000ff;
        }
    }

    // Pop excess numbers
    for(int i = (Output.size() - N); i > 0; i--){ Output.pop_back(); }

    // Pop transient
    Output.erase(Output.begin(), Output.begin() + 10000);

    // Write numbers to a file as decimals
    ofstream fileDecimal("seed.ent");
    for (const auto& number : Output) { fileDecimal << (int) number << std::endl; }
    fileDecimal.close();

    /*ofstream fileSamples("samples.txt");
    for (uint64_t i = 9999; i < RequiredSamples; i++) { fileSamples << (int) Samples[i] << std::endl; }
    fileSamples.close();*/

    
    return 0;
}
