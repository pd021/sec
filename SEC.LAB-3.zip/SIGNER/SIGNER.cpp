#include <stdio.h>
#include <cstdlib>
#include <cstdint>
#include <vector>
#include <cstring>
#include <fstream>
#include <cryptopp/rsa.h>
#include <cryptopp/osrng.h>
#include <cryptopp/base64.h>
#include <cryptopp/filters.h>
#include <cryptopp/hex.h>
#include "eyecandy.h"
using namespace std;
using namespace CryptoPP;

// CONST
const char* TRNGPath       = "./TRNG";
const char* SeedFilePath   = "seed.ent";
const char* PublicKeyPath  = "public.key";
const char* PrivateKeyPath = "private.key";
// CONST

void Key2String(const CryptoPP::RSA::PublicKey& Key, string& OutputString) {
    CryptoPP::Base64Encoder B64Encoder;
    Key.DEREncode(B64Encoder);
    B64Encoder.MessageEnd();

    CryptoPP::word64 OutputSize = B64Encoder.MaxRetrievable();
    if(OutputSize) {
        OutputString.resize(OutputSize);
        B64Encoder.Get((CryptoPP::byte*)&OutputString[0], OutputString.size());
    }
}

void Key2String(const CryptoPP::RSA::PrivateKey& Key, string& OutputString) {
    CryptoPP::Base64Encoder B64Encoder;
    Key.DEREncode(B64Encoder);
    B64Encoder.MessageEnd();

    CryptoPP::word64 OutputSize = B64Encoder.MaxRetrievable();
    if(OutputSize) {
        OutputString.resize(OutputSize);
        B64Encoder.Get((CryptoPP::byte*)&OutputString[0], OutputString.size());
    }
}

string LoadKeyString(const char* Filepath) {
    ifstream KeyFile(Filepath);
    string Key((istreambuf_iterator<char>(KeyFile)), istreambuf_iterator<char>());
    return Key;
}

CryptoPP::RSA::PublicKey LoadPublicKey(const char* FilePath) {
    ifstream KeyFile(FilePath);
    if (!KeyFile) { throw runtime_error("[ERR] Unable to load public key!"); }
    string PublicKeyB64((istreambuf_iterator<char>(KeyFile)), istreambuf_iterator<char>());

    string KeyString;
    CryptoPP::StringSource(PublicKeyB64, true,
        new CryptoPP::Base64Decoder(
            new CryptoPP::StringSink(KeyString)
        )
    );

    CryptoPP::RSA::PrivateKey PublicKey;
    PublicKey.Load(CryptoPP::StringSource(KeyString, true).Ref());

    KeyFile.close();
    return PublicKey;
}

CryptoPP::RSA::PrivateKey LoadPrivateKey(const char* FilePath) {
    ifstream KeyFile(FilePath);
    if (!KeyFile) { throw runtime_error("[ERR] Unable to load private key!"); }
    string PrivateKeyB64((istreambuf_iterator<char>(KeyFile)), istreambuf_iterator<char>());

    string KeyString;
    CryptoPP::StringSource(PrivateKeyB64, true,
        new CryptoPP::Base64Decoder(
            new CryptoPP::StringSink(KeyString)
        )
    );

    CryptoPP::RSA::PrivateKey PrivateKey;
    PrivateKey.Load(CryptoPP::StringSource(KeyString, true).Ref());

    KeyFile.close();
    return PrivateKey;
}

void Module_Usage(char* executable) {
    printf("Usage:\n");
    printf("  Generate keys:\n  %s --generate-keys\n\n", executable);
    printf("  Sign message:\n  %s --sign <unsigned message file>\n\n", executable);
    printf("  Verify signature:\n  %s --verify <signed message file>\n\n", executable);
}

int Module_GenerateKeys() {
    // Summon TRNG wizard
    printf(BLUE "[INF]" NOBOLD GREEN " Running TRNG... (this might take a while)\n" RESET);
    int TRNGResult = system(TRNGPath);
    if(TRNGResult != 0) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " TRNG error. %s\n" RESET); return 1; }
    printf(BLUE "[INF]" NOBOLD GREEN " TRNG finished.\n" RESET);

    // Load entropy
    FILE* SeedFile = fopen(SeedFilePath, "rb");
    if (SeedFile == nullptr) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error opening file %s\n" RESET, SeedFilePath); return 1; }
    vector<uint8_t> Seeds;
    uint8_t InputBuffer;
    while ( fread(&InputBuffer, sizeof(uint8_t), 1, SeedFile) == 1 ) { Seeds.push_back(InputBuffer); }
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Loaded %d entropy points.\n", Seeds.size());
    fclose(SeedFile);

    // Seeds -> SHA256
    CryptoPP::SecByteBlock SeedBlock(Seeds.data(), Seeds.size());
    CryptoPP::SHA256 TempHash;
    CryptoPP::SecByteBlock SeedHash(TempHash.DigestSize());
    TempHash.Update(SeedBlock, SeedBlock.size());
    TempHash.Final(SeedHash);

    // Sprinkle some entropy into PRNG
    CryptoPP::AutoSeededRandomPool PRNG;
    PRNG.IncorporateEntropy(SeedHash, SeedHash.size());

    // Generate RSA private key
    CryptoPP::RSA::PrivateKey PrivateKey;
    PrivateKey.GenerateRandomWithKeySize(PRNG, 4096);
    // Generate Public Key derived from private key
    CryptoPP::RSA::PublicKey PublicKey(PrivateKey);

    // Save keys in readable form
    string PublicKeyString  = "";
    string PrivateKeyString = "";
    Key2String(  PublicKey, PublicKeyString  );
    Key2String( PrivateKey, PrivateKeyString );

    // Save public key to file
    FILE* PublicKeyFile = fopen(PublicKeyPath, "w");
    if (PublicKeyFile == nullptr) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error creating file %s\n" RESET, PublicKeyPath); return 1; }
    size_t Result = fwrite(PublicKeyString.c_str(), sizeof(char), strlen(PublicKeyString.c_str()), PublicKeyFile);
    if (Result != strlen(PublicKeyString.c_str())) {
        printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error saving file %s\n" RESET, PublicKeyPath);
        fclose(PublicKeyFile);
        return 1;
    }

    fclose(PublicKeyFile);

    // Save public key to file
    FILE* PrivateKeyFile = fopen(PrivateKeyPath, "w");
    if (PrivateKeyFile == nullptr) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error creating file %s\n" RESET, PrivateKeyPath); return 1; }
    Result = fwrite(PrivateKeyString.c_str(), sizeof(char), strlen(PrivateKeyString.c_str()), PrivateKeyFile);
    if (Result != strlen(PrivateKeyString.c_str())) {
        printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error saving file %s\n" RESET, PrivateKeyPath);
        fclose(PrivateKeyFile);
        return 1;
    }
    fclose(PrivateKeyFile);
    
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Keypair generated succesfully.\n" RESET);
    return 0;
}

int Module_Sign (string MessageFilePath) {
    // Load the unsigned message
    vector <string> Message;
    string Accumulator = "", LineBuffer = "";
    ifstream MessageFile(MessageFilePath);
    if (!MessageFile) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error opening message file %s\n" RESET, MessageFilePath.c_str()); return 1; }
    while (getline(MessageFile, LineBuffer)) {
        Accumulator += LineBuffer;
        Message.push_back(LineBuffer);
    }
    MessageFile.close();

    // Setup TRNG for encryption

    // Summon TRNG wizard
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Running TRNG... (this might take a while)\n" RESET);
    int TRNGResult = system(TRNGPath);
    if(TRNGResult != 0) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " TRNG error. %s\n" RESET); return 1; }
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " TRNG finished.\n" RESET);

    // Load entropy
    FILE* SeedFile = fopen(SeedFilePath, "rb");
    if (SeedFile == nullptr) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error opening file %s\n" RESET, SeedFilePath); return 1; }
    vector<uint8_t> Seeds;
    uint8_t InputBuffer;
    while ( fread(&InputBuffer, sizeof(uint8_t), 1, SeedFile) == 1 ) { Seeds.push_back(InputBuffer); }
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Loaded %d entropy points.\n", Seeds.size());
    fclose(SeedFile);

    // Seeds -> SHA256
    CryptoPP::SecByteBlock SeedBlock(Seeds.data(), Seeds.size());
    CryptoPP::SHA256 TempHash;
    CryptoPP::SecByteBlock SeedHash(TempHash.DigestSize());
    TempHash.Update(SeedBlock, SeedBlock.size());
    TempHash.Final(SeedHash);

    // Sprinkle some entropy into PRNG
    CryptoPP::AutoSeededRandomPool PRNG;
    PRNG.IncorporateEntropy(SeedHash, SeedHash.size());

    // Load keys
    string PublicKey = LoadKeyString(PublicKeyPath);
    CryptoPP::RSA::PrivateKey PrivateKey = LoadPrivateKey(PrivateKeyPath);

    // Actual signature generation
    RSASS<PKCS1v15, SHA256>::Signer Signer(PrivateKey);
    size_t SignatureLength = Signer.MaxSignatureLength();
    string Signature(SignatureLength, '\0');
    SignatureLength = Signer.SignMessage(PRNG, (const CryptoPP::byte*)Accumulator.data(), Accumulator.size(), (CryptoPP::byte*)&Signature[0]);
    Signature.resize(SignatureLength);
    string SignatureB64 = "";
    StringSource(Signature, true, new Base64Encoder(new StringSink(SignatureB64)));

    // Get new filename
    size_t LastDotPos = MessageFilePath.find_last_of('.');
    if (LastDotPos == std::string::npos) {
        // If there is no extension, just append "_signed"
        MessageFilePath += "_signed";
    } else {
        // Insert "_signed" before the extension
        MessageFilePath = MessageFilePath.substr(0, LastDotPos) + "_signed" + MessageFilePath.substr(LastDotPos);
    }
    
    // Bundle it all together
    ofstream MessageSignedFile(MessageFilePath, std::ios::out);
    if (!MessageSignedFile) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error creating message file %s\n" RESET, MessageFilePath.c_str()); return 1; }
    MessageSignedFile << "============================== BEGIN PUBLIC KEY ==============================" << endl;
    MessageSignedFile << PublicKey;
    MessageSignedFile << "=============================== END PUBLIC KEY ===============================" << endl;
    MessageSignedFile << "============================== BEGIN SIGNATURE ===============================" << endl;
    MessageSignedFile << SignatureB64;
    MessageSignedFile << "=============================== END SIGNATURE ================================" << endl;
    MessageSignedFile << "=============================== BEGIN MESSAGE ================================" << endl;
    for (uint32_t i = 0; i < Message.size(); i++) {
        //if (i != Message.size() - 1) { MessageSignedFile << endl; }
        MessageSignedFile << Message[i] << endl;
    }
    MessageSignedFile << "================================ END MESSAGE =================================";
    MessageSignedFile.close();

    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Message signed successfully.\n");

    return 0;
}

int Module_Verify (string MessageFilePath) {
    // Load file
    ifstream MessageFile(MessageFilePath);
    if (!MessageFile) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Error opening message file %s\n" RESET, MessageFilePath.c_str()); return 1; }
    string LineBuffer = "";

    // Read public key
    getline(MessageFile, LineBuffer);
    if (LineBuffer != "============================== BEGIN PUBLIC KEY ==============================")
    { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Message file corrupt.\n" RESET); return 1; }
    string PublicKeyB64 = "";
    CryptoPP::RSA::PublicKey PublicKey;
    while (getline(MessageFile, LineBuffer)) {
        if (LineBuffer == "=============================== END PUBLIC KEY ===============================") {
            string KeyString;
            CryptoPP::StringSource(PublicKeyB64, true,
                new CryptoPP::Base64Decoder(
                    new CryptoPP::StringSink(KeyString)
                )
            );
            PublicKey.Load(CryptoPP::StringSource(KeyString, true).Ref());
            break;
        }
        PublicKeyB64 += LineBuffer;
    }
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Public key loaded.\n" RESET);
    
    // Read signature
    getline(MessageFile, LineBuffer);
    if (LineBuffer != "============================== BEGIN SIGNATURE ===============================")
    { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Message file corrupt.\n" RESET); return 1; }
    string SignatureB64 = "", Signature = "";
    while (getline(MessageFile, LineBuffer)) {
        if (LineBuffer == "=============================== END SIGNATURE ================================") {
            CryptoPP::StringSource(SignatureB64, true,
                new CryptoPP::Base64Decoder(
                    new CryptoPP::StringSink(Signature)
                )
            );
            break;
        }
        SignatureB64 += LineBuffer;
    }
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Signature loaded.\n" RESET);

    // Get message
    getline(MessageFile, LineBuffer);
    if (LineBuffer != "=============================== BEGIN MESSAGE ================================")
    { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Message file corrupt.\n" RESET); return 1; }
    string Accumulator = "";
    while (getline(MessageFile, LineBuffer)) {
        if (LineBuffer == "================================ END MESSAGE =================================") { break; }
        Accumulator += LineBuffer;
    }
    printf(BLUE BOLD "[INF]" NOBOLD GREEN " Message loaded.\n" RESET);
    MessageFile.close();
    
    // Verify signature
    RSASS<PKCS1v15, SHA256>::Verifier Verifier(PublicKey);
    bool isValid = Verifier.VerifyMessage((const CryptoPP::byte*)Accumulator.data(), Accumulator.size(), (const CryptoPP::byte*)Signature.data(), Signature.size());
    if(isValid){
        printf(GREEN BOLD "##############################\n");
        printf(GREEN BOLD "#  Message verification OK.  #\n");
        printf(GREEN BOLD "##############################\n");
    } else {
        printf(RED BOLD "##############################\n");
        printf(RED BOLD "# Message verification FAIL. #\n");
        printf(RED BOLD "##############################\n");
    }
    
    return 0;
}

int main(int argc, char* argv[]) {
    // Check for wrong number of parameters
    if (argc < 2 || argc > 3) { Module_Usage(argv[0]); return 1; }

    string Mode = argv[1];

    if (Mode == "--generate-keys") {
        int Result = Module_GenerateKeys();
        if(Result != 0) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Exited with errors.\n" RESET); }
        return 0;
    }

    else if (Mode == "--sign" || Mode == "--verify") {

        // Parameter ammount check
        if (argc != 3) { Module_Usage(argv[0]); return 0; }

        string MessageFile = argv[2];

        if (Mode == "--sign") {
            int Result = Module_Sign(MessageFile);
            if(Result != 0) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Exited with errors.\n" RESET); }
            return 0;
        }

        if (Mode == "--verify") {
            int Result = Module_Verify(MessageFile);
            if(Result != 0) { printf(RED BOLD "[" BLINK "ERR" NOBLINK "]" NOBOLD YELLOW " Exited with errors.\n" RESET); }
            return 0;
        }
    }

    Module_Usage(argv[0]);
    return 0;
}